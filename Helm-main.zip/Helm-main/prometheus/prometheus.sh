
# add the prometheus-community repo as follows:
$ helm repo add prometheus-community https://prometheus-community.github.io/helm-charts

#You can then run "helm search" to see the available charts charts.
$ helm search repo prometheus-community

